from flask import Flask, request, jsonify
import sqlite3
import os

app = Flask(__name__)
DB_PATH = os.path.join("data", "school.db")

def get_db():
    return sqlite3.connect(DB_PATH)

def fetch_one_by_id(table, obj_id):
    conn = get_db()
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM {table} WHERE id=?", (obj_id,))
    row = cur.fetchone()
    conn.close()
    return row

def validate_fields(data, required):
    for field in required:
        if field not in data:
            return {'error': f'{field} is required'}, 500
    return None, 200

# student eedn
@app.route("/student", methods=["POST", "GET", "DELETE"])
def student():
    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        data = request.json
        error, code = validate_fields(data, ["name", "email", "phone", "year", "status"])
        if error:
            return jsonify(error), code

        cur.execute("""
        INSERT INTO students (name, email, phone, year, status)
        VALUES (?, ?, ?, ?, ?)""", (data["name"], data["email"], data["phone"], data["year"], data["status"]))
        conn.commit()
        new_id = cur.lastrowid
        conn.close()
        return jsonify({"id": new_id})

    elif request.method == "GET":
        student_id = request.args.get("id")
        if not student_id:
            return jsonify({'error': 'id is required'}), 500
        row = fetch_one_by_id("students", student_id)
        return jsonify(row) if row else jsonify({"error": "Student not found"}), 404

    elif request.method == "DELETE":
        data = request.get_json()
        student_id = data.get("id")
        if not student_id:
            return jsonify({'error': 'id is required'}), 500
        cur.execute("DELETE FROM students WHERE id=?", (student_id,))
        conn.commit()
        conn.close()
        return jsonify({"message": f"Student {student_id} deleted."})

# techer end
@app.route("/teacher", methods=["POST", "GET", "DELETE"])
def teacher():
    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        data = request.json
        error, code = validate_fields(data, ["name", "email", "phone"])
        if error:
            return jsonify(error), code

        cur.execute("""
        INSERT INTO teachers (name, email, phone)
        VALUES (?, ?, ?)""", (data["name"], data["email"], data["phone"]))
        conn.commit()
        new_id = cur.lastrowid
        conn.close()
        return jsonify({"id": new_id})

    elif request.method == "GET":
        teacher_id = request.args.get("id")
        if not teacher_id:
            return jsonify({'error': 'id is required'}), 500

        row = fetch_one_by_id("teachers", teacher_id)
        if not row:
            return jsonify({"error": "Teacher not found"}), 404

        teacher_data = {
            "id": row[0],
            "name": row[1],
            "email": row[2],
            "phone": row[3]
        }

        if request.args.get("count") == "true":
            cur.execute("SELECT COUNT(*) FROM classes WHERE teacher_id=?", (teacher_id,))
            count = cur.fetchone()[0]
            teacher_data["count"] = count

        return jsonify(teacher_data)

    elif request.method == "DELETE":
        data = request.get_json()
        teacher_id = data.get("id")
        if not teacher_id:
            return jsonify({'error': 'id is required'}), 500
        cur.execute("DELETE FROM teachers WHERE id=?", (teacher_id,))
        conn.commit()
        conn.close()
        return jsonify({"message": f"Teacher {teacher_id} deleted."})

# class end
@app.route("/class", methods=["POST", "GET", "DELETE"])
def class_():
    conn = get_db()
    cur = conn.cursor()

    if request.method == "POST":
        data = request.json
        error, code = validate_fields(data, ["name", "teacher_id"])
        if error:
            return jsonify(error), code

        department = data.get("department", "Misc")
        cur.execute("""
        INSERT INTO classes (name, department, teacher_id)
        VALUES (?, ?, ?)""", (data["name"], department, data["teacher_id"]))
        conn.commit()
        new_id = cur.lastrowid
        conn.close()
        return jsonify({"id": new_id})

    elif request.method == "GET":
        if request.args.get("count") == "true":
            cur.execute("SELECT COUNT(*) FROM classes")
            count = cur.fetchone()[0]
            conn.close()
            return jsonify({"count": count})

        class_id = request.args.get("id")
        if not class_id:
            return jsonify({'error': 'id is required'}), 500
        row = fetch_one_by_id("classes", class_id)
        return jsonify(row) if row else jsonify({"error": "Class not found"}), 404

    elif request.method == "DELETE":
        class_id = request.args.get("id")
        if not class_id:
            return jsonify({'error': 'id is required'}), 500
        cur.execute("DELETE FROM classes WHERE id=?", (class_id,))
        conn.commit()
        conn.close()
        return jsonify({"message": f"Class {class_id} deleted."})

# pbone update
@app.route("/update_student_phone")
def update_student_phone():
    student_id = request.args.get("id")
    phone = request.args.get("phone")
    if not student_id or not phone:
        return jsonify({'error': 'id and phone are required'}), 500
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE students SET phone=? WHERE id=?", (phone, student_id))
    conn.commit()
    conn.close()
    return jsonify({"message": f"Student {student_id} phone updated."})

@app.route("/update_teacher_phone")
def update_teacher_phone():
    teacher_id = request.args.get("id")
    phone = request.args.get("phone")
    if not teacher_id or not phone:
        return jsonify({'error': 'id and phone are required'}), 500
    conn = get_db()
    cur = conn.cursor()
    cur.execute("UPDATE teachers SET phone=? WHERE id=?", (phone, teacher_id))
    conn.commit()
    conn.close()
    return jsonify({"message": f"Teacher {teacher_id} phone updated."})

# run if
if __name__ == "__main__":
    app.run(debug=True)