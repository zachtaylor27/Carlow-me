import sqlite3
import os

DB_PATH = os.path.join("data", "school.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    # Drop tables (if they exist)
    cur.executescript("""
    DROP TABLE IF EXISTS students;
    DROP TABLE IF EXISTS teachers;
    DROP TABLE IF EXISTS classes;
    DROP TABLE IF EXISTS schools;
    """)

    # Create tables
    cur.execute("""
    CREATE TABLE schools (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        location TEXT,
        ranking INTEGER
    );
    """)

    cur.execute("""
    CREATE TABLE teachers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        school_id INTEGER,
        FOREIGN KEY (school_id) REFERENCES schools(id)
    );
    """)

    cur.execute("""
    CREATE TABLE students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        year TEXT NOT NULL,
        status TEXT NOT NULL,
        school_id INTEGER,
        FOREIGN KEY (school_id) REFERENCES schools(id)
    );
    """)

    cur.execute("""
    CREATE TABLE classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        department TEXT DEFAULT 'Misc',
        teacher_id INTEGER NOT NULL,
        school_id INTEGER,
        FOREIGN KEY (teacher_id) REFERENCES teachers(id),
        FOREIGN KEY (school_id) REFERENCES schools(id)
    );
    """)

    conn.commit()
    conn.close()
    print("Database initialized successfully.")

if __name__ == "__main__":
    init_db()